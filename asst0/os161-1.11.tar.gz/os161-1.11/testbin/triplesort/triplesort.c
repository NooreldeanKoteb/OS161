/*
 * triplesort.c
 *
 * 	Calls three copies of /testbin/sort.
 *
 * When the VM assignment is complete, your system should survive this.
 */

#include "triple.h"

int
main()
{
	triple("/testbin/sort");
	return 0;
}

